package com.app.pojos;

public enum Dept {

	HR,RnD,BILLING
}
